// ----
// ---- file   : tkzip.cpp
// ---- author : Bastian Spiegel <bs@tkscript.de>
// ---- legal  : (c) 2020 by Bastian Spiegel. 
// ----          Distributed under terms of the GNU LESSER GENERAL PUBLIC LICENSE (LGPL). See 
// ----          http://www.gnu.org/licenses/licenses.html#LGPL or COPYING for further information.
// ----
// ---- info   : libzip interface
// ----
// ---- changed: 04Jan2020
// ----
// ----
// ----

#include <stdio.h>
#include <stdarg.h>
#include <math.h>

#define YAC_BIGSTRING
#define YAC_PRINTF
#include <yac.h>
YAC_Host *yac_host;

#include <zip.h>

#include "tkzip.h"

#include "ying_zip.h"

#include "ying_zip_Zip.cpp"

#include "ying_zip.cpp"


// Implement standard exception ID variables (see yac.h)
Dyac_std_exid_impl;


// ---------------------------------------------------------------------------- Zip
Zip::Zip(void) {
   zip = NULL;
}

Zip::~Zip() {
   close();
}

void Zip::close(void) {
   if(NULL != zip)
   {
      zip_close(zip);
      zip = NULL;
   }
}

sBool Zip::openLocalReadOnly(YAC_String *_pathName) {
   close();

   if(YAC_Is_String(_pathName))
   {
      int error;
      zip = zip_open((const char*)_pathName->chars, ZIP_RDONLY, &error);
   }

   return (NULL != zip);
}



// ---------------------------------------------------------------------------- YAC_Init
void YAC_CALL YAC_Init(YAC_Host *_host) {
	yac_host = _host;

   // Resolve "standard" exception IDs
   Dyac_std_exid_resolve;

   YAC_Init_zip(_host);
   yac_host->printf("tkzip: init done.\n");
}

void YAC_CALL YAC_Exit(YAC_Host *_host) {
   YAC_Exit_zip(_host);
}


#include <yac_host.cpp>
