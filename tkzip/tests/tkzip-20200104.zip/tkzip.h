// ----
// ---- file   : tkzip.h
// ---- author : Bastian Spiegel <bs@tkscript.de>
// ---- legal  : (c) 2020 by Bastian Spiegel. 
// ----          Distributed under terms of the GNU LESSER GENERAL PUBLIC LICENSE (LGPL). See 
// ----          http://www.gnu.org/licenses/licenses.html#LGPL or COPYING for further information.
// ----
// ---- info   : libzip interface
// ----
// ---- changed: 04Jan2020
// ----
// ----
// ----

#ifndef __TKZIP_H__
#define __TKZIP_H__


YG("zip")

YC class Zip  : public YAC_Object {
  protected:
   zip_t *zip;

	public:
		YAC(Zip);

      Zip(void);
      ~Zip();

  public:
      YM sBool openLocalReadOnly (YAC_String *_pathName);
      YM void close (void);
};



#endif // __TKZIP_H__

